const { Op } = require("sequelize");
const Employee = require("../models/employee");

const router = require("express").Router();

router
  .route("/employees")
  .get(async (req, res) => {
    const { minSalary, simplified, name } = req.query;

    try {
      const where = {};
      if (minSalary) {
        where.salary = { [Op.gt]: minSalary };
      }
      if (name) {
        where.firstName = { [Op.like]: `%${name}%` };
      }

      const employees = await Employee.findAll({
        where: Object.keys(where).length ? where : undefined,
        attributes: simplified ? { exclude: ["id"] } : undefined,
      });

      return res.status(200).json(employees);
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .post(async (req, res) => {
    try {
      const newEmployee = await Employee.create(req.body);
      return res.status(200).json(newEmployee);
    } catch (err) {
      return res.status(500).json(err);
    }
  });

router
  .route("/employees/:id")
  .get(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (!employee) {
        return res
          .status(404)
          .json({ error: `Employee with id ${req.params.id} does not exists` });
      }
      return res.status(200).json(employee);
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .put(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (!employee) {
        return res
          .status(404)
          .json({ error: `Employee with id ${req.params.id} does not exists` });
      }
      const updated = await employee.update(req.body);
      return res.status(200).json(updated);
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .delete(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (!employee) {
        return res
          .status(404)
          .json({ error: `Employee with id ${req.params.id} does not exists` });
      }
      await employee.destroy();
      return res.status(204).send();
    } catch (err) {
      return res.status(500).json(err);
    }
  });

module.exports = router;
