const express = require("express");
const app = express();
const port = 3000;

const sequelize = require("./sequelize");

const University = require("./models/university");
const Student = require("./models/student");
const Course = require("./models/course");

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

University.hasMany(Student, { foreignKey: "universityId", onDelete: "CASCADE" });
Student.belongsTo(University, { foreignKey: "universityId" });

University.hasMany(Course, { foreignKey: "universityId", onDelete: "CASCADE" });
Course.belongsTo(University, { foreignKey: "universityId" });

Student.belongsToMany(Course, { through: "enrollements" });
Course.belongsToMany(Student, { through: "enrollements" });

app.get("/create", async (req, res, next) => {
  try {
    await sequelize.sync({ force: true });
    res.status(201).json({ message: "Database created with the models." });
  } catch (err) {
    next(err);
  }
});

app.put("/", async (req, res, next) => {
  try {
    await sequelize.sync({ force: true });
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.get("/universities", async (req, res, next) => {
  try {
    const universities = await University.findAll();
    if (universities.length > 0) res.status(200).json(universities);
    else res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.post("/university", async (req, res, next) => {
  try {
    const university = await University.create(req.body);
    res.status(201).json(university);
  } catch (err) {
    next(err);
  }
});

app.post("/universities", async (req, res, next) => {
  try {
    const university = await University.create(req.body);
    res.status(201).location(String(university.id)).send();
  } catch (err) {
    next(err);
  }
});

app.get("/students", async (req, res, next) => {
  try {
    const students = await Student.findAll();
    if (students.length > 0) res.status(200).json(students);
    else res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/students", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId, { include: [Student] });
    if (!university) return res.status(404).json({ message: "404 - University Not Found!" });
    if (university.students && university.students.length > 0) return res.status(200).json(university.students);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.post("/universities/:universityId/students", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.status(404).json({ message: "404 - University Not Found!" });

    const student = await Student.create({
      studentFullName: req.body.studentFullName ?? req.body.fullName,
      studentStatus: req.body.studentStatus ?? req.body.status,
      universityId: university.id
    });

    res.status(201).json(student);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/students/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.status(404).json({ message: "404 - University Not Found!" });

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!student) return res.status(404).json({ message: "404 - Student Not Found!" });
    res.status(202).json(student);
  } catch (err) {
    next(err);
  }
});

app.put("/universities/:universityId/students/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.status(404).json({ message: "404 - University Not Found!" });

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!student) return res.status(404).json({ message: "404 - Student Not Found!" });

    const fullName = req.body.studentFullName ?? req.body.fullName;
    const status = req.body.studentStatus ?? req.body.status;

    if (fullName !== undefined) student.studentFullName = fullName;
    if (status !== undefined) student.studentStatus = status;

    await student.save();
    res.status(202).json({ message: "Student updated!" });
  } catch (err) {
    next(err);
  }
});

app.delete("/universities/:universityId/students/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.status(404).json({ message: "404 - University Not Found!" });

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!student) return res.status(404).json({ message: "404 - Student Not Found!" });

    await student.destroy();
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/courses", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses();
    if (courses.length > 0) res.json(courses);
    else res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/courses/:courseId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    if (!course) return res.sendStatus(404);
    res.json(course);
  } catch (err) {
    next(err);
  }
});

app.post("/universities/:universityId/courses", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const course = await Course.create({
      name: req.body.name,
      universityId: university.id
    });

    res.status(201).json(course);
  } catch (err) {
    next(err);
  }
});

app.put("/universities/:universityId/courses/:courseId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    if (!course) return res.sendStatus(404);

    await course.update(req.body);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.delete("/universities/:universityId/courses/:courseId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    if (!course) return res.sendStatus(404);

    await course.destroy();
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.post("/universities/:universityId/students/:studentId/enrollements/:courseId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    if (!student || !course) return res.sendStatus(404);

    await student.addCourse(course);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.delete("/universities/:universityId/students/:studentId/enrollements/:courseId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    if (!student || !course) return res.sendStatus(404);

    await student.removeCourse(course);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/courses/:courseId/enrollements", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    if (!course) return res.sendStatus(404);

    const students = await course.getStudents({ attributes: ["id"] });
    if (students.length > 0) res.json(students);
    else res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.post("/universities/:universityId/courses/:courseId/enrollements/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!course || !student) return res.sendStatus(404);

    await course.addStudent(student);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.delete("/universities/:universityId/courses/:courseId/enrollements/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const courses = await university.getCourses({ where: { id: req.params.courseId } });
    const course = courses.shift();

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!course || !student) return res.sendStatus(404);

    await course.removeStudent(student);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/students/:studentId/enrollements", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) return res.sendStatus(404);

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!student) return res.sendStatus(404);

    const courses = await student.getCourses({ attributes: ["id", "name"] });
    if (courses.length > 0) res.json(courses);
    else res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "500 - Server Error" });
});

app.listen(port, () => {
  console.log("The server is running on http://localhost:" + port);
});
