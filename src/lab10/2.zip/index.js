const express = require("express");
const app = express();
const port = 3000;

const sequelize = require("./sequelize");
const University = require("./models/university");
const Student = require("./models/student");

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

University.hasMany(Student, { foreignKey: "universityId", onDelete: "CASCADE" });
Student.belongsTo(University, { foreignKey: "universityId" });

app.get("/create", async (req, res, next) => {
  try {
    await sequelize.sync({ force: true });
    res.status(201).json({ message: "Database created with the models." });
  } catch (err) {
    next(err);
  }
});

app.get("/universities", async (req, res, next) => {
  try {
    const universities = await University.findAll();
    res.status(200).json(universities);
  } catch (err) {
    next(err);
  }
});

app.post("/university", async (req, res, next) => {
  try {
    const university = await University.create({
      universityName: req.body.universityName
    });
    res.status(201).json(university);
  } catch (err) {
    next(err);
  }
});

app.get("/students", async (req, res, next) => {
  try {
    const students = await Student.findAll();
    res.status(200).json(students);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/students", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId, {
      include: [Student]
    });
    if (!university) {
      return res.status(404).json({ message: "404 - University Not Found!" });
    }
    res.status(200).json(university.students);
  } catch (err) {
    next(err);
  }
});

app.post("/universities/:universityId/students", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) {
      return res.status(404).json({ message: "404 - University Not Found!" });
    }

    const student = await Student.create({
      studentFullName: req.body.studentFullName,
      studentStatus: req.body.studentStatus,
      universityId: university.id
    });

    res.status(201).json(student);
  } catch (err) {
    next(err);
  }
});

app.get("/universities/:universityId/students/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId, {
      include: [Student]
    });

    if (!university) {
      return res.status(404).json({ message: "404 - University Not Found!" });
    }

    const studentId = Number(req.params.studentId);
    const student = (university.students || []).find((s) => s.id === studentId);

    if (!student) {
      return res.status(404).json({ message: "404 - Student Not Found!" });
    }

    res.status(200).json(student);
  } catch (err) {
    next(err);
  }
});

app.put("/universities/:universityId/students/:studentId", async (req, res, next) => {
  try {
    const university = await University.findByPk(req.params.universityId);
    if (!university) {
      return res.status(404).json({ message: "404 - University Not Found!" });
    }

    const students = await university.getStudents({ where: { id: req.params.studentId } });
    const student = students.shift();

    if (!student) {
      return res.status(404).json({ message: "404 - Student Not Found!" });
    }

    student.studentFullName = req.body.studentFullName;
    student.studentStatus = req.body.studentStatus;
    await student.save();

    res.status(202).json(student);
  } catch (err) {
    next(err);
  }
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "500 - Server Error" });
});

app.listen(port, () => {
  console.log("The server is running on http://localhost:" + port);
});
