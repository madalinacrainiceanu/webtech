const express = require('express')
const cors = require('cors')

const app = express()
app.use(cors())

const users = [
  {
    id: 1,
    username: 'popescu_i',
    fullName: 'Ion Popescu',
    email: 'ion@test.com',
    job: 'Programator Junior',
    bio: 'Pasionat de React si Node.js'
  },
  {
    id: 2,
    username: 'ionescu_m',
    fullName: 'Maria Ionescu',
    email: 'maria@test.com',
    job: 'Designer UX/UI',
    bio: 'Ii place sa deseneze interfete moderne.'
  },
  {
    id: 3,
    username: 'radulescu_d',
    fullName: 'Dan Radulescu',
    email: 'dan@test.com',
    job: 'Project Manager',
    bio: 'Expert in organizarea echipelor.'
  }
]

app.get('/users', (req, res) => {
  res.status(200).json(users)
})

app.listen(8080, () => {
  console.log('Server is running on port 8080')
})